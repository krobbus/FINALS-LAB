<?php

include 'connect.php';

if(isset($_POST['signUp'])){
    $firstName=$_POST['fName'];
    $lastName=$_POST['lName'];
    $email=$_POST['email'];
    $pwd=$_POST['pwd'];
    $pwd=md5($pwd);

        $checkEmail="SELECT * from users where email='$email'";
        $result=$conn->query($checkEmail);
        if ($result->num_rows > 0){
            echo "Email Already Exists!";
        }
            else{
                $insertQuery="INSERT INTO users(firstName, lastName, email, pwd)
                                VALUES ('$firstName', '$lastName', '$email', '$pwd')";
                                if ($conn->query($insertQuery) == TRUE){
                                    header("location: index.php");
                                }
                                    else {
                                        echo "Error".$conn->error;
                                    }
            }
    }
        if(isset($_POST['signIn'])){
            $email=$_POST['email'];
            $pwd=$_POST['pwd'];
            $pwd=md5($pwd);

            $sql="SELECT * FROM users WHERE email = '$email' and pwd = '$pwd'";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                session_start();
                $row=$result->fetch_assoc();
                $_SESSION['email']=$row['email'];
                header("Location: homepage.php");
                exit();
            }
                else{
                    echo "Not Found, Incorrect Email or Password";
                }
    }

?>