<?php

$host="localhost";
$users="root";
$pass="";
$db="accounts";
$conn=new mysqli($host, $users, $pass, $db);
if ($conn->connect_error){
    echo "Failed to connect to Database".$conn->connect_error;
}


?>