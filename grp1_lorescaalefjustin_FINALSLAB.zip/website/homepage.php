<?php
session_start();
include("connect.php");

// Check if there's a last search cookie and set it to the input value
$lastSearch = isset($_COOKIE['lastSearch']) ? $_COOKIE['lastSearch'] : '';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Animal Search Website</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="homepage.css">
</head>
<body>

<div class="content">
    <div style="text-align:center; padding: 10px;">
        <p style="font: size 20px; font-weight:bold;">
            HELLO 
            <?php 
            if (isset($_SESSION['email'])) {
                $email = $_SESSION['email'];
                $query = mysqli_query($conn, "SELECT users.* FROM `users` WHERE users.email='$email'");
                while ($row = mysqli_fetch_array($query)) {
                    echo $row['firstName'].' '.$row['lastName'];
                }
            }
            ?>
            Welcome to AniPedia
        </p>
    </div>
</div>

<div id="search-container">
    <h1>Animal Search</h1>
    <input type="text" id="search-input" placeholder="Search for an animal..." value="<?php echo htmlspecialchars($lastSearch); ?>">
    <button id="search-btn">Search</button>
    <div id="result"></div>
    <ul id="suggestions"></ul>
</div>

<script>
$(document).ready(function() {
    
    $('#search-input').val(getCookie('lastSearch'));

    $('#search-btn').click(function() {
        var searchQuery = $('#search-input').val();
        
        document.cookie = "lastSearch=" + encodeURIComponent(searchQuery) + "; path=/; max-age=" + (7 * 24 * 60 * 60);

        $.ajax({
            type: 'GET',
            url: 'search.php',
            data: { query: searchQuery },
            dataType: 'json',
            success: function(data) {
                if (data.found) {
                    $('#result').html('<h2>' + data.animal.name + '</h2><p>' + data.animal.description + '</p>');
                } else {
                    $('#result').html('<p>Animal not found.</p>');
                }
            }
        });
    });

    $('#search-input').keyup(function() {
        var searchQuery = $(this).val();

        if (searchQuery.length > 1) {
            $.ajax({
                type: 'GET',
                url: 'suggest.php',
                data: { query: searchQuery },
                dataType: 'json',
                success: function(data) {
                    $('#suggestions').empty();
                    $.each(data, function(index, value) {
                        $('#suggestions').append('<li>' + value + '</li>');
                    });
                    $('#suggestions').show();
                }
            });
        } else {
            $('#suggestions').hide();
        }
    });

    $('#suggestions').on('click', 'li', function() {
        $('#search-input').val($(this).text());
        $('#suggestions').hide();
    });
});

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}
</script>

</body>
</html>